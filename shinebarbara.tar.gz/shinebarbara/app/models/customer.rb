class Customer < ActiveRecord::Base
end
