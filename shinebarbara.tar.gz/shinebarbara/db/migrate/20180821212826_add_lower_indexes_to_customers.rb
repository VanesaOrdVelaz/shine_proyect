class AddLowerIndexesToCustomers < ActiveRecord::Migration
  def change

  end
end
